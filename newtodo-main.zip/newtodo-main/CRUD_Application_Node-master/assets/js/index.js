


$("#add_user").submit(function(event){
    alert("Data Inserted Successfully!");
})

